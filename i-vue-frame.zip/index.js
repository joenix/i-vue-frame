import iframe from "./iframe.vue";

export default {
  install(Vue) {
    Vue.component("i-vue-frame", iframe);
  }
};
